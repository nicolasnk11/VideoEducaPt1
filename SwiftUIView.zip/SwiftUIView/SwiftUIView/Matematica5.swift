//
//  Matematica5.swift
//  VideoEduca
//
//  Created by User on 20/10/23.
//

import SwiftUI

struct Matematica5: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Matematica5()
}
