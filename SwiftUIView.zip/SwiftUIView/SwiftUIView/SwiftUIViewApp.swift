//
//  SwiftUIViewApp.swift
//  SwiftUIView
//
//  Created by User on 17/10/23.
//

import SwiftUI

@main
struct SwiftUIViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
