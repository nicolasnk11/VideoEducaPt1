//
//  ContentView.swift
//  SwiftUIView
//
//  Created by User on 17/10/23.
//

import SwiftUI

struct ContentView: View {
    @AppStorage("username") var username: String = ""
    @AppStorage("E-mail") var email: String = ""
    
    var body: some View {
        NavigationStack {
            VStack {
                Text("Quem é você?") // Título no topo da tela
                    .font(.system(size: 40, weight: .bold))
                
                
                Text("Nome:")
                
                TextField("Insira seu nome", text: $username)
                    .fixedSize()
                    .textFieldStyle(.roundedBorder)
                    .multilineTextAlignment(.center)
                
                
                Text("E-mail:")
                TextField("Insira seu E-mail", text: $email)
                    .fixedSize()
                    .textFieldStyle(.roundedBorder)
                    .multilineTextAlignment(.leading)
                
                NavigationLink("Próximo"){
                    HelloView()
                }
            }
        }
    }
}





#Preview {
    ContentView()
}
